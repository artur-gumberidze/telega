package com.project.createbd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreatebdApplicationTests {

	@Test
	void contextLoads() {
	}

}
